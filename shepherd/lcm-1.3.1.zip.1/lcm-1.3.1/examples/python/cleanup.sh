#!/bin/sh

rm -f *.pyc
rm -rf exlcm
