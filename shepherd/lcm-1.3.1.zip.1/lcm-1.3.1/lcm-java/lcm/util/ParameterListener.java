package lcm.util;

public interface ParameterListener
{
    public void parameterChanged(String name);
}

