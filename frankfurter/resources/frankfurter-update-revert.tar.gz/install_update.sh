#!/bin/bash

####################################################################################
# Instructions to install a specific update. Packaged in the tarballs used to
# distribute updates.
####################################################################################

HOME_DIR=/home/ubuntu
UPDATES_DIR=$HOME_DIR/updates
RUNTIME_DIR=$HOME_DIR/daemon/runtime

####################################################################################
# Update hibike:                                                                   #
####################################################################################
if [ -d $HOME_DIR/hibike_old ]; then
	rm -rf $HOME_DIR/hibike
	mv $HOME_DIR/hibike_old $HOME_DIR/hibike
fi


####################################################################################
# Update runtime:                                                                  #
# This is a bit more involved as we need to avoid deleting student code.           #
####################################################################################
if [ -d $HOME_DIR/daemon_old ]; then
	rm -rf $HOME_DIR/daemon_old/runtime/student_code
	cp -r $RUNTIME_DIR/student_code $HOME_DIR/daemon_old/runtime
	rm -rf $HOME_DIR/daemon
	mv $HOME_DIR/daemon_old $HOME_DIR/daemon
	rm $RUNTIME_DIR/hibikeDevices.csv
	ln -s $HOME_DIR/hibike/hibikeDevices.csv $RUNTIME_DIR/hibikeDevices.csv
fi
